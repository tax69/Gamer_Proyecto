const About = () => {
    return(
        <div>
            <h1>View About</h1>
        </div>
    )
}
export default About