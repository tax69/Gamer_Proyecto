const Contact = () => {
    return(
        <div>
            <h1>View Contact</h1>
        </div>
    )
}
export default Contact