const Home = () => {
    return(
        <div>
            <h1>View Home</h1>
        </div>
    )
}
export default Home