import "./App.css";
import Cards from "./components/Cards";

function App() {
  return (
    <div className="App">
      <Cards />
    </div>
  );
}

export default App;
